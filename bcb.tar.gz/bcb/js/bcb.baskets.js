function createBaskets(productNames, colors, donuts) {
  for (var name in productNames) {
    $('#all-bucket').append('<div data-id="'+name+'" class="product-labels"><h6><span class="label label-default" style="background-color:'+colors[name]+'">  '+productNames[name]+'  </span></h6></div>');
  }
  dragula([document.getElementById("all-bucket"), document.getElementById("yes-bucket"),document.getElementById("no-bucket")], {
    revertOnSpill: true
  }).on('drop', function () {
    yesFilter = getFilters($('#yes-bucket').children());
    noFilter = getFilters($('#no-bucket').children());
    donuts.update(yesFilter, noFilter);
  });
}

function getFilters(objs) {
  var filterStr = "";
  for (var i=0;i<objs.length;i++) {
    filterStr += '-'+objs[i]['attributes']['data-id'].value;
  }
  return filterStr.substring(1,filterStr.length);
}
