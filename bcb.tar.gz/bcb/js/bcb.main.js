var colors = {
  "curr": "#5687d1",
  "svng": "#7b615c",
  "mort": "#de783b",
  "only": "#bbbbbb"
};

var productNames = {
  "curr": "Current",
  "svng": "Saving",
  "mort": "Mortgage"
};

var customerSegments = {
  "c": "Community",
  "b": "Business",
  "w": "Wealth",
  "p": "Premier"
}

var unit = ['K'];
var cat = ['Community', 'Business', 'Wealth', 'Premier'];
var type = ['Customers'];

var dataConstruct = "curr-svng-mort";
var dataConstructArray = dataConstruct.split('-');
var csvData = "";
var filterData = "";

var verbatimTemplate = {
  'intro': 'There are ~TOTAL customers within Barclays UK',
  'yes-filter': ' have ~YES-PRODUCTS products',
  'no-filter': ' do not have ~NO-PRODUCTS products'
}

$(function() {
  $('#main-body-container').css("min-height",innerHeight - 80);
  var fileName = "data.csv";
  readDataFile(fileName);
});

function readDataFile(fileName) {
  d3.text(fileName, function(text) {
    csvData = d3.csv.parseRows(text);
    var yesFilter = "";
    var noFilter = "";
    var donutData = genData(yesFilter, noFilter);
    var donuts = new DonutCharts();
    donuts.create(donutData);
    createBaskets(productNames, colors, donuts);
  });
}

function parseFilters(yesFilter, noFilter) {
  var binaryFilter = "";
  var dataArray = dataConstruct.split("-");
  dataArray.forEach(function(a) {
    if(yesFilter.includes(a)) binaryFilter += '1';
    else if(noFilter.includes(a)) binaryFilter += '0';
    else binaryFilter += '.';
  });
  return binaryFilter;
}

function filterDataset(binaryFilter) {
  var regPattern = new RegExp(binaryFilter);
  var response = {};
  response['type'] = type[0];
  response['unit'] = unit[0];
  response['total'] = 0;
  response['data'] = [];

  for(var segment in customerSegments) {
    var x = {};
    x['cat'] = customerSegments[segment];
    x['val'] = 0;
    response['data'].push(x);
  }
  for(var i=0;i<csvData.length;i++) {
    if(regPattern.test(csvData[i][0])) {
      response['total'] += parseInt(csvData[i][2]);
      response['data'][Object.keys(customerSegments).indexOf(csvData[i][1])]['val'] += parseInt(csvData[i][2]);
    }
  }
  return response;
}

function createProductListText(binaryFilter,flag) {
  var indices = [];
  var returnText = "";
  for(var i=0; i<binaryFilter.length; i++) {
    if (binaryFilter[i] === flag) indices.push(i);
  }
  if(indices.length == 1) {
    returnText += productNames[dataConstructArray[indices[0]]];
  }
  else if(indices.length == binaryFilter.length) {
    returnText = "all";
  }
  else {
    for(var j=0; j<indices.length-1; j++) {
      returnText += ', ' + productNames[dataConstructArray[indices[j]]];
    }
    returnText = returnText.substring(1,returnText.length) + ' and ' + productNames[dataConstructArray[indices[indices.length-1]]];
  }
  return returnText;
}

function parseVerbatim(binaryFilter,filteredData) {
  var parsedVerbatim = {};
  var finalText = '';
  parsedVerbatim['intro'] = verbatimTemplate['intro'].replace('~TOTAL',filteredData.total);
  if(binaryFilter.indexOf('1') > -1) {
    productList = createProductListText(binaryFilter,'1');
    parsedVerbatim['yes-filter'] = verbatimTemplate['yes-filter'].replace('~YES-PRODUCTS',productList);
  }
  if(binaryFilter.indexOf('0') > -1) {
    productList = createProductListText(binaryFilter,'0');
    parsedVerbatim['no-filter'] = verbatimTemplate['no-filter'].replace('~NO-PRODUCTS',productList);
  }
  finalText += parsedVerbatim['intro'];
  if ('yes-filter' in parsedVerbatim || 'no-filter' in parsedVerbatim) {
    finalText += ' who ';
    if ('yes-filter' in parsedVerbatim && 'no-filter' in parsedVerbatim) {
      finalText += parsedVerbatim['yes-filter'] + ' but ' + parsedVerbatim['no-filter'];
    }
    else {
      if ('yes-filter' in parsedVerbatim) finalText += parsedVerbatim['yes-filter'];
      else finalText += parsedVerbatim['no-filter'];
    }
  }
  $('#verbatim').text(finalText);
}

function genData(yesFilter, noFilter) {
  var binaryFilter = parseFilters(yesFilter, noFilter);
  var filteredData = filterDataset(binaryFilter);
  parseVerbatim(binaryFilter,filteredData);
  var dataset = new Array();
  dataset.push(filteredData);
  console.log(dataset);
  return dataset;
}
